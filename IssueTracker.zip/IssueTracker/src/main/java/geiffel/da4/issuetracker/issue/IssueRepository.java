package geiffel.da4.issuetracker.issue;

import geiffel.da4.issuetracker.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IssueRepository  extends JpaRepository<Issue, Long> {


}
