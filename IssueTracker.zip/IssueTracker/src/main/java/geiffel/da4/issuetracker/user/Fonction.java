package geiffel.da4.issuetracker.user;

public enum Fonction {
    USER, DEVELOPPER
}
