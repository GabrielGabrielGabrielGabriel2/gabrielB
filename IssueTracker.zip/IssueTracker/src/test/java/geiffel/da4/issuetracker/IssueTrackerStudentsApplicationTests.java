package geiffel.da4.issuetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueTrackerStudentsApplicationTests {

    @Test
    void contextLoads() {
    }

}
