package geiffel.da4.issuetracker.Projet;

import org.junit.jupiter.api.Test;
import org.mockito.internal.matchers.Equals;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProjetLocalServiceTest {

    List<Projet> projet= new ArrayList<>(){{
        add(new Projet(1L,"projet1"));
        add(new Projet(2L,"sameblaze"));
        add(new Projet(3L,"sameblaze"));
        add(new Projet(4L,"sameblaze"));
    }};

    private final ProjetService projetService=new ProjetLocalService(projet);

    @Test
    void Testgetall(){
        List<Projet> lesprojets = projetService.getAll();
        assertEquals(4,lesprojets.size());
    }

    @Test
    void TestgetByCode(){
        projetService.getByCode(1L);
        assertEquals(1L,"projet1");


    }


}
