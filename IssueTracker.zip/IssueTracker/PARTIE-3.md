# TP IssueTracker : découverte de Spring et des API REST

## Partie 3 : voler de ses propres ailes

Le but de cette partie 3 est de créer un package commentaire, et d'implémenter cette feature.

Le code final doit correspondre au [diagramme de classe de l'application complète][full-app-uml]

Aidez-vous du [cours][cours-api-spring] et de votre travail précédent




[full-app-uml]: https://drive.google.com/file/d/1CeDW1-Vm3tQ8xy1E3f0JQp80gs_eO0vq/view?usp=sharing
[cours-api-spring]: https://nathanael-gimenez.canoprof.fr/eleve/DA4%20-%20Programmation%20Avanc%C3%A9e/activities/API_REST_avec_Spring.html